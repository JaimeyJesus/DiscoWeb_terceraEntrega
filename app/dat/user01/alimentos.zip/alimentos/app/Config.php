 <?php

 class Config
 {
     static public $mvc_bd_hostname = "192.168.1.199";
     static public $mvc_bd_nombre   = "alimentos";
     static public $mvc_bd_usuario  = "root";
     static public $mvc_bd_clave    = "root";
     static public $mvc_vis_css     = "estilo.css";
 }
